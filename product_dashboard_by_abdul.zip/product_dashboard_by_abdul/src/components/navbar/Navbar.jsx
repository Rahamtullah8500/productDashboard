import './Navbar.css';

const Navbar = () => {
  return (
    <nav className="navbar">
    <div className="navbar-brand">TECHNOMIND | Product Dashboard by Abdul</div>
  </nav>
  )
}

export default Navbar